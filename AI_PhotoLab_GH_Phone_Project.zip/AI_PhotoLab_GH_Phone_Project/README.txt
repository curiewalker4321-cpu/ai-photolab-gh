AI PhotoLab GH PHONE APP PROJECT

This is a PWA/web-app project prepared for a phone-based APK builder.

Import the WWW folder into a compatible APK/WebView builder.
The app includes:
- AI PhotoLab GH branding
- Install App button
- Add-to-home-screen support
- Mobile-friendly interface
- Photo selection and preview
- GH₵5 starting price

The ZIP contains all required files.
